
import { GoogleGenAI } from "@google/genai";

// Initialize with the API key from environment variables
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getGeminiResponse = async (userPrompt: string, lang: 'en' | 'hi') => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userPrompt,
      config: {
        systemInstruction: `You are "Innovation Sahayak", a friendly assistant for the "Innovation Educational and Charitable Trust" NGO. 
        Your goal is to help students, parents, and donors.
        The NGO offers:
        1. Free and affordable higher education support through "PRAGATI INDIA" mission.
        2. 100% Scholarship assistance for technical and professional courses (B.Tech, B.Sc, BBA, etc.).
        3. Educational Helpline: 9161-04-2518.
        4. WhatsApp Support: 9161-04-2518.
        5. Registered Office: Near Veena Hospital, Gopalgarh, NH-28, Kasia, Kushinagar-274402.
        Answer in ${lang === 'en' ? 'English' : 'Hindi'}. Be polite, encouraging, and clear. Keep answers short and suitable for a mobile chat.`,
        temperature: 0.7,
      },
    });
    // Access the text property directly from the response
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return lang === 'en' ? "I'm sorry, I'm having trouble connecting right now. Please try again." : "क्षमा करें, मुझे अभी जुड़ने में परेशानी हो रही है। कृपया पुनः प्रयास करें।";
  }
};
