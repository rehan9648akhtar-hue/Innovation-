
import { Translation, Course, Event, CourseCategory } from './types';

export const TRANSLATIONS: Translation = {
  navHome: { en: 'Home', hi: 'होम' },
  navAbout: { en: 'About', hi: 'परिचय' },
  navCourses: { en: 'Courses', hi: 'कोर्स' },
  navDonate: { en: 'Donate', hi: 'दान दें' },
  navMore: { en: 'More', hi: 'अधिक' },
  welcome: { 
    en: 'Welcome to Innovation Educational and Charitable Trust', 
    hi: 'इनोवेशन एजुकेशनल एंड चैरिटेबल ट्रस्ट में आपका स्वागत है' 
  },
  tagline: { en: 'Empowering communities through education', hi: 'शिक्षा के माध्यम से समुदायों को सशक्त बनाना' },
  mission: { en: 'Our Mission', hi: 'हमारा लक्ष्य' },
  vision: { en: 'Our Vision', hi: 'हमारा दृष्टिकोण' },
  missionText: { en: 'To provide accessible education to every child in India.', hi: 'भारत के हर बच्चे को सुलभ शिक्षा प्रदान करना।' },
  visionText: { en: 'A future where education is a right, not a privilege.', hi: 'एक ऐसा भविष्य जहाँ शिक्षा एक अधिकार है, विशेषाधिकार नहीं।' },
  enrollNow: { en: 'Enroll Now', hi: 'अभी नामांकन करें' },
  volunteer: { en: 'Volunteer', hi: 'स्वयंसेवक' },
  latestEvents: { en: 'Our Impact', hi: 'हमारा प्रभाव' },
  freeCourses: { en: 'Free Courses', hi: 'मुफ्त कोर्स' },
  contactUs: { en: 'Contact Us', hi: 'संपर्क करें' },
  fullName: { en: 'Full Name', hi: 'पूरा नाम' },
  email: { en: 'Email', hi: 'ईमेल' },
  phone: { en: 'Phone Number', hi: 'फोन नंबर' },
  submit: { en: 'Submit', hi: 'जमा करें' },
  courseOverview: { en: 'Course Overview', hi: 'कोर्स अवलोकन' },
  prerequisites: { en: 'Prerequisites', hi: 'आवश्यक शर्तें' },
  careerOpportunities: { en: 'Career Opportunities', hi: 'करियर के अवसर' },
  applyForScholarship: { en: 'Apply for Scholarship', hi: 'छात्रवृत्ति के लिए आवेदन करें' },
  applyNow: { en: 'Apply Now', hi: 'अभी आवेदन करें' },
};

export const CATEGORY_PLACEHOLDERS: Record<CourseCategory, string> = {
  technical: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=400',
  paramedical: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=400',
  management: 'https://images.unsplash.com/photo-1454165833767-02a92209f30b?w=400',
  agriculture: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=400',
  education: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400',
  law: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=400',
  others: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400'
};

export const COURSES: Course[] = [
  // Engineering B.Tech
  {
    id: 'btech-cse',
    title: { en: 'B.Tech Computer Science', hi: 'बी.टेक कंप्यूटर विज्ञान' },
    shortDescription: { en: 'Software, AI, and Algorithms.', hi: 'सॉफ्टवेयर, एआई और एल्गोरिदम।' },
    fullDescription: { en: 'Focus on software development, cloud computing, and cybersecurity.', hi: 'सॉफ्टवेयर विकास, क्लाउड कंप्यूटिंग और साइबर सुरक्षा पर ध्यान दें।' },
    prerequisites: { en: ['12th PCM'], hi: ['12वीं PCM'] },
    careerProspects: { en: ['Software Engineer', 'Developer'], hi: ['सॉफ्टवेयर इंजीनियर', 'डेवलपर'] },
    category: 'technical',
    level: '12th',
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600',
    duration: '4 Years',
    isScholarship: true
  },
  {
    id: 'btech-aero',
    title: { en: 'B.Tech Aerospace', hi: 'बी.टेक एयरोस्पेस' },
    shortDescription: { en: 'Aircraft and Spacecraft design.', hi: 'विमान और अंतरिक्ष यान डिजाइन।' },
    fullDescription: { en: 'Advanced study of aerodynamics and propulsion.', hi: 'एरोडायनामिक्स और प्रणोदन का उन्नत अध्ययन।' },
    prerequisites: { en: ['12th PCM'], hi: ['12वीं PCM'] },
    careerProspects: { en: ['Design Engineer'], hi: ['डिजाइन इंजीनियर'] },
    category: 'technical',
    level: '12th',
    image: 'https://images.unsplash.com/photo-1517976487492-5750f3195933?w=600',
    duration: '4 Years',
    isScholarship: true
  },
  // Paramedical
  {
    id: 'bsc-nursing',
    title: { en: 'B.Sc Nursing', hi: 'बी.एससी नर्सिंग' },
    shortDescription: { en: 'Professional patient care.', hi: 'पेशेवर रोगी देखभाल।' },
    fullDescription: { en: 'Comprehensive training in healthcare and clinical practices.', hi: 'स्वास्थ्य देखभाल और नैदानिक प्रथाओं में व्यापक प्रशिक्षण।' },
    prerequisites: { en: ['12th PCB'], hi: ['12वीं PCB'] },
    careerProspects: { en: ['Registered Nurse'], hi: ['पंजीकृत नर्स'] },
    category: 'paramedical',
    level: '12th',
    image: 'https://images.unsplash.com/photo-1586773860418-d3b97898c713?w=600',
    duration: '4 Years',
    isScholarship: true
  },
  // Management
  {
    id: 'bba-gen',
    title: { en: 'BBA', hi: 'बीबीए' },
    shortDescription: { en: 'Business Administration.', hi: 'व्यवसाय प्रशासन।' },
    fullDescription: { en: 'Foundation in management, marketing, and finance.', hi: 'प्रबंधन, विपणन और वित्त में नींव।' },
    prerequisites: { en: ['12th Any Stream'], hi: ['12वीं कोई भी स्ट्रीम'] },
    careerProspects: { en: ['Manager'], hi: ['मैनेजर'] },
    category: 'management',
    level: '12th',
    image: 'https://images.unsplash.com/photo-1454165833767-02a92209f30b?w=600',
    duration: '3 Years',
    isScholarship: true
  }
];

export const EVENTS: Event[] = [
  {
    id: 'e1',
    title: { en: 'Scholarship Distribution Ceremony', hi: 'छात्रवृत्ति वितरण समारोह' },
    date: 'Oct 15, 2024',
    location: 'Kushinagar, UP',
    image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=400'
  },
  {
    id: 'e2',
    title: { en: 'Skill Development Workshop', hi: 'कौशल विकास कार्यशाला' },
    date: 'Nov 02, 2024',
    location: 'Gopalgarh, NH-28',
    image: 'https://images.unsplash.com/photo-1513258496099-48168024adb0?w=400'
  },
  {
    id: 'e3',
    title: { en: 'Higher Education Guidance', hi: 'उच्च शिक्षा मार्गदर्शन' },
    date: 'Dec 10, 2024',
    location: 'Lucknow, UP',
    image: 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=400'
  }
];

export const STATES_FOR_HIGHER_EDU = [
  "NCR/New Delhi", "Chandigarh", "Punjab", "Haryana", 
  "W. Bengal", "Rajasthan", "Pune / Nashik", "Chennai",
  "Odisha", "Bangalore", "UP", "MP", "Andhra Pradesh", "Other State"
];

export const EDUCATIONAL_QUALIFICATIONS = [
  "10th Matric", "Intermediate 10+2", "Graduation/ B-Tech", "any other"
];
