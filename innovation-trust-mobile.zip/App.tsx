
import React, { useState } from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Language } from './types';
import Header from './components/Header';
import BottomNav from './components/BottomNav';
import Home from './pages/Home';
import About from './pages/About';
import Courses from './pages/Courses';
import CourseDetails from './pages/CourseDetails';
import Donate from './pages/Donate';
import Enroll from './pages/Enroll';
import More from './pages/More';
import AiAssistant from './components/AiAssistant';

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>('en');

  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-slate-50 font-sans selection:bg-blue-100">
        <Header lang={lang} setLang={setLang} />
        
        <main className="flex-1 overflow-x-hidden">
          <Routes>
            <Route path="/" element={<Home lang={lang} />} />
            <Route path="/about" element={<About lang={lang} />} />
            <Route path="/courses" element={<Courses lang={lang} />} />
            <Route path="/courses/:courseId" element={<CourseDetails lang={lang} />} />
            <Route path="/donate" element={<Donate lang={lang} />} />
            <Route path="/enroll" element={<Enroll lang={lang} />} />
            <Route path="/more" element={<More lang={lang} />} />
            {/* Fallback routes for demo pages */}
            <Route path="/volunteer" element={<Enroll lang={lang} />} />
            <Route path="/events" element={<Home lang={lang} />} />
            <Route path="/gallery" element={<Home lang={lang} />} />
            <Route path="/privacy" element={<Home lang={lang} />} />
            <Route path="/terms" element={<Home lang={lang} />} />
            <Route path="/faq" element={<Home lang={lang} />} />
          </Routes>
        </main>

        <AiAssistant lang={lang} />
        <BottomNav lang={lang} />
      </div>
    </Router>
  );
};

export default App;
