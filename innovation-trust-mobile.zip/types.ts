
export type Language = 'en' | 'hi';

export interface Translation {
  [key: string]: {
    en: string;
    hi: string;
  };
}

export type CourseLevel = '10th' | '12th' | 'grad';
export type CourseCategory = 'technical' | 'paramedical' | 'management' | 'agriculture' | 'education' | 'law' | 'others';

export interface Course {
  id: string;
  title: { en: string; hi: string };
  shortDescription: { en: string; hi: string };
  fullDescription: { en: string; hi: string };
  prerequisites: { en: string[]; hi: string[] };
  careerProspects: { en: string[]; hi: string[] };
  category: CourseCategory;
  level: CourseLevel;
  image: string;
  duration: string;
  isScholarship: boolean;
}

export interface Event {
  id: string;
  title: { en: string; hi: string };
  date: string;
  location: string;
  image: string;
}
