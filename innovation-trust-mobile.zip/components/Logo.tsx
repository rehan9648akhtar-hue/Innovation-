
import React from 'react';

const Logo: React.FC<{ className?: string }> = ({ className = "w-10 h-10" }) => {
  return (
    <div className={`${className} flex items-center justify-center`}>
      {/* SVG Reconstruction of the Innovation Trust Logo: Bulb, World, Person, Book, Wreath */}
      <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Wreath */}
        <path d="M25 60C20 50 20 35 25 25M75 60C80 50 80 35 75 25" stroke="#228B22" strokeWidth="2" strokeLinecap="round" />
        <circle cx="23" cy="25" r="2" fill="#228B22" />
        <circle cx="23" cy="35" r="2" fill="#228B22" />
        <circle cx="23" cy="45" r="2" fill="#228B22" />
        <circle cx="77" cy="25" r="2" fill="#228B22" />
        <circle cx="77" cy="35" r="2" fill="#228B22" />
        <circle cx="77" cy="45" r="2" fill="#228B22" />
        
        {/* Open Book */}
        <path d="M20 65C35 60 50 65 50 70C50 65 65 60 80 65V85C65 80 50 85 50 90C50 85 35 80 20 85V65Z" fill="#0047AB" />
        <path d="M50 70C50 65 65 60 80 65" stroke="#FFA500" strokeWidth="2" />
        
        {/* Person reaching out */}
        <circle cx="50" cy="45" r="4" fill="#FF8C00" />
        <path d="M42 65C45 55 50 50 50 50L58 35" stroke="#FF8C00" strokeWidth="3" strokeLinecap="round" />
        
        {/* Lightbulb with World */}
        <path d="M40 30C40 20 60 20 60 30C60 40 55 42 55 45H45C45 42 40 40 40 30Z" fill="#FFA500" stroke="#FFA500" />
        <circle cx="50" cy="30" r="7" fill="#1E90FF" />
        {/* Abstract continents */}
        <path d="M48 27C49 26 51 26 52 27L53 30C52 31 48 31 47 30L48 27Z" fill="#32CD32" />
        
        {/* Rays */}
        <line x1="50" y1="12" x2="50" y2="18" stroke="#FFA500" strokeWidth="2" strokeLinecap="round" />
        <line x1="35" y1="18" x2="40" y2="22" stroke="#FFA500" strokeWidth="2" strokeLinecap="round" />
        <line x1="65" y1="18" x2="60" y2="22" stroke="#FFA500" strokeWidth="2" strokeLinecap="round" />
      </svg>
    </div>
  );
};

export default Logo;
