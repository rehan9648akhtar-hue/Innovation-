
import React from 'react';
import { Home, Info, BookOpen, Heart, Menu } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { TRANSLATIONS } from '../constants';
import { Language } from '../types';

interface BottomNavProps {
  lang: Language;
}

const BottomNav: React.FC<BottomNavProps> = ({ lang }) => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;

  const navItems = [
    { path: '/', icon: Home, label: TRANSLATIONS.navHome[lang] },
    { path: '/courses', icon: BookOpen, label: TRANSLATIONS.navCourses[lang] },
    { path: '/donate', icon: Heart, label: TRANSLATIONS.navDonate[lang] },
    { path: '/about', icon: Info, label: TRANSLATIONS.navAbout[lang] },
    { path: '/more', icon: Menu, label: TRANSLATIONS.navMore[lang] },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-slate-200 safe-bottom">
      <div className="max-w-lg mx-auto px-2 h-16 flex items-center justify-around">
        {navItems.map((item) => {
          const ActiveIcon = item.icon;
          const active = isActive(item.path);
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center justify-center w-full h-full transition-colors ${
                active ? 'text-blue-600' : 'text-slate-500'
              }`}
            >
              <ActiveIcon size={22} className={active ? 'scale-110' : ''} />
              <span className="text-[10px] mt-1 font-medium">{item.label}</span>
              {active && <div className="absolute top-0 w-8 h-1 bg-blue-600 rounded-b-full" />}
            </Link>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;
