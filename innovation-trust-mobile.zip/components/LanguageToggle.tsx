
import React from 'react';
import { Language } from '../types';

interface LanguageToggleProps {
  currentLang: Language;
  onToggle: (lang: Language) => void;
}

const LanguageToggle: React.FC<LanguageToggleProps> = ({ currentLang, onToggle }) => {
  return (
    <div className="flex items-center gap-1 bg-white/20 p-1 rounded-full border border-white/30 backdrop-blur-sm">
      <button
        onClick={() => onToggle('en')}
        className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
          currentLang === 'en' ? 'bg-white text-blue-600 shadow-sm' : 'text-white'
        }`}
      >
        EN
      </button>
      <button
        onClick={() => onToggle('hi')}
        className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
          currentLang === 'hi' ? 'bg-white text-blue-600 shadow-sm' : 'text-white'
        }`}
      >
        हिंदी
      </button>
    </div>
  );
};

export default LanguageToggle;
