
import React from 'react';
import { Language } from '../types';
import LanguageToggle from './LanguageToggle';
import Logo from './Logo';

interface HeaderProps {
  lang: Language;
  setLang: (l: Language) => void;
}

const Header: React.FC<HeaderProps> = ({ lang, setLang }) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-white text-slate-800 shadow-sm border-b border-slate-100">
      <div className="flex items-center justify-between px-4 h-16 max-w-lg mx-auto">
        <div className="flex items-center gap-3">
          <Logo className="w-10 h-10" />
          <div>
            <h1 className="text-sm font-black leading-tight text-blue-900 tracking-tight">INNOVATION</h1>
            <p className="text-[9px] text-orange-600 font-bold uppercase tracking-tighter">Educational & Charitable Trust</p>
          </div>
        </div>
        <div className="bg-blue-600 rounded-full p-0.5">
          <LanguageToggle currentLang={lang} onToggle={setLang} />
        </div>
      </div>
    </header>
  );
};

export default Header;
