
import React, { useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Clock, 
  GraduationCap, 
  CheckCircle2, 
  Briefcase, 
  ListChecks, 
  Info,
  Award
} from 'lucide-react';
import { COURSES, TRANSLATIONS, CATEGORY_PLACEHOLDERS } from '../constants';
import { Language } from '../types';

interface CourseDetailsProps {
  lang: Language;
}

const CourseDetails: React.FC<CourseDetailsProps> = ({ lang }) => {
  const { courseId } = useParams<{ courseId: string }>();
  const navigate = useNavigate();
  const course = COURSES.find(c => c.id === courseId);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (!course) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-6 text-center">
        <Info size={48} className="text-slate-300 mb-4" />
        <h2 className="text-xl font-bold text-slate-800">Course Not Found</h2>
        <button onClick={() => navigate('/courses')} className="mt-4 text-blue-600 font-bold">Back to Courses</button>
      </div>
    );
  }

  const courseImage = course.image || CATEGORY_PLACEHOLDERS[course.category];

  return (
    <div className="pb-32 bg-white min-h-screen">
      {/* Hero Section */}
      <div className="relative h-64 sm:h-80 overflow-hidden">
        <img 
          src={courseImage} 
          alt={course.title[lang]} 
          className="w-full h-full object-cover"
          onError={(e) => {
            (e.target as HTMLImageElement).src = CATEGORY_PLACEHOLDERS.others;
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
        <button 
          onClick={() => navigate(-1)} 
          className="absolute top-4 left-4 bg-white/20 backdrop-blur-md p-2 rounded-full text-white hover:bg-white/40 transition-all"
        >
          <ArrowLeft size={24} />
        </button>
        
        <div className="absolute bottom-6 left-6 right-6 text-white">
          <div className="flex items-center gap-2 mb-2">
            <span className="bg-blue-600 text-[10px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider">
              {course.category}
            </span>
            {course.isScholarship && (
              <span className="bg-orange-600 text-[10px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider flex items-center gap-1 shadow-lg">
                <Award size={10} />
                {lang === 'en' ? 'Scholarship' : 'छात्रवृत्ति'}
              </span>
            )}
          </div>
          <h1 className="text-2xl font-black leading-tight tracking-tight">{course.title[lang]}</h1>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 py-8 max-w-lg mx-auto">
        {/* Quick Info Bar */}
        <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl mb-8 border border-slate-100">
          <div className="flex flex-col items-center text-center">
            <Clock size={20} className="text-blue-600 mb-1" />
            <span className="text-[10px] text-slate-400 font-black uppercase">{lang === 'en' ? 'Duration' : 'अवधि'}</span>
            <span className="text-xs font-bold text-slate-800">{course.duration}</span>
          </div>
          <div className="h-8 w-px bg-slate-200" />
          <div className="flex flex-col items-center text-center">
            <GraduationCap size={20} className="text-emerald-600 mb-1" />
            <span className="text-[10px] text-slate-400 font-black uppercase">{lang === 'en' ? 'Level' : 'स्तर'}</span>
            <span className="text-xs font-bold text-slate-800">{course.level === 'grad' ? (lang === 'en' ? 'Graduate' : 'स्नातक') : course.level}</span>
          </div>
          <div className="h-8 w-px bg-slate-200" />
          <div className="flex flex-col items-center text-center">
            <CheckCircle2 size={20} className="text-orange-600 mb-1" />
            <span className="text-[10px] text-slate-400 font-black uppercase">{lang === 'en' ? 'Entry' : 'प्रवेश'}</span>
            <span className="text-xs font-bold text-slate-800">{lang === 'en' ? 'Open' : 'खुला है'}</span>
          </div>
        </div>

        {/* Overview */}
        <div className="mb-10">
          <div className="flex items-center gap-2 mb-4">
            <div className="bg-blue-100 p-2 rounded-lg text-blue-600">
              <Info size={18} />
            </div>
            <h2 className="text-lg font-black text-slate-800 tracking-tight">{TRANSLATIONS.courseOverview[lang]}</h2>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed opacity-90">
            {course.fullDescription[lang]}
          </p>
        </div>

        {/* Prerequisites */}
        <div className="mb-10">
          <div className="flex items-center gap-2 mb-4">
            <div className="bg-orange-100 p-2 rounded-lg text-orange-600">
              <ListChecks size={18} />
            </div>
            <h2 className="text-lg font-black text-slate-800 tracking-tight">{TRANSLATIONS.prerequisites[lang]}</h2>
          </div>
          <div className="space-y-3">
            {course.prerequisites[lang].map((item, idx) => (
              <div key={idx} className="flex items-start gap-3 bg-slate-50/50 p-3 rounded-xl border border-slate-100/50">
                <div className="mt-1 w-1.5 h-1.5 rounded-full bg-orange-400 flex-shrink-0" />
                <span className="text-sm text-slate-600 font-medium leading-tight">{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Career Opportunities */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <div className="bg-emerald-100 p-2 rounded-lg text-emerald-600">
              <Briefcase size={18} />
            </div>
            <h2 className="text-lg font-black text-slate-800 tracking-tight">{TRANSLATIONS.careerOpportunities[lang]}</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {course.careerProspects[lang].map((item, idx) => (
              <span key={idx} className="bg-white border border-slate-200 px-4 py-2 rounded-full text-xs font-bold text-slate-600 shadow-sm">
                {item}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Sticky Bottom Action Bar */}
      <div className="fixed bottom-16 left-0 right-0 z-40 px-6 pb-6 pt-4 bg-white/90 backdrop-blur-md border-t border-slate-100 max-w-lg mx-auto">
        <Link 
          to="/enroll"
          state={{ courseName: course.title[lang] }}
          className="w-full bg-blue-600 text-white h-14 rounded-2xl flex items-center justify-center font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-200 active:scale-[0.98] transition-all"
        >
          {course.isScholarship ? TRANSLATIONS.applyForScholarship[lang] : TRANSLATIONS.applyNow[lang]}
        </Link>
      </div>
    </div>
  );
};

export default CourseDetails;
