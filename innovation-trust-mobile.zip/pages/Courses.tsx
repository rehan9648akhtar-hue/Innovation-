
import React, { useState } from 'react';
import { Search, Clock, GraduationCap, Award, ChevronRight, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { COURSES, CATEGORY_PLACEHOLDERS } from '../constants';
import { Language, CourseCategory, CourseLevel } from '../types';

interface CoursesProps {
  lang: Language;
}

const Courses: React.FC<CoursesProps> = ({ lang }) => {
  const navigate = useNavigate();
  const [level, setLevel] = useState<CourseLevel>('12th');
  const [activeTab, setActiveTab] = useState<CourseCategory | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = COURSES.filter(course => {
    const matchesLevel = course.level === level;
    const matchesTab = activeTab === 'all' || course.category === activeTab;
    const matchesSearch = course.title[lang].toLowerCase().includes(searchQuery.toLowerCase());
    return matchesLevel && matchesTab && matchesSearch;
  });

  const getCategoryLabel = (cat: CourseCategory | 'all') => {
    switch (cat) {
      case 'all': return lang === 'en' ? 'All' : 'सभी';
      case 'technical': return lang === 'en' ? 'Technical' : 'तकनीकी';
      case 'paramedical': return lang === 'en' ? 'Para-Medical' : 'पैरा-मेडिकल';
      case 'management': return lang === 'en' ? 'Management' : 'प्रबंधन';
      case 'agriculture': return lang === 'en' ? 'Agriculture' : 'कृषि';
      case 'education': return lang === 'en' ? 'Education' : 'शिक्षा';
      case 'law': return lang === 'en' ? 'Law' : 'कानून';
      default: return cat;
    }
  };

  const levelLabels = {
    '10th': lang === 'en' ? 'After 10th' : '10वीं के बाद',
    '12th': lang === 'en' ? 'After 12th' : '12वीं के बाद',
    'grad': lang === 'en' ? 'After Grad' : 'स्नातक के बाद',
  };

  const categories: (CourseCategory | 'all')[] = ['all', 'technical', 'paramedical', 'management', 'agriculture', 'education', 'law'];

  return (
    <div className="pb-24 px-4 max-w-lg mx-auto pt-6">
      <div className="bg-gradient-to-br from-blue-700 to-blue-900 rounded-3xl p-6 text-white mb-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-[-10%] right-[-10%] opacity-10">
          <GraduationCap size={160} />
        </div>
        <div className="relative z-10">
          <h2 className="text-2xl font-black mb-2 tracking-tight">
            {lang === 'en' ? 'Mission PRAGATI INDIA' : 'मिशन प्रगति इण्डिया'}
          </h2>
          <p className="text-blue-100 text-sm mb-4 leading-relaxed opacity-90">
            {lang === 'en' 
              ? 'Join our 100% Scholarship campaign for high-demand technical and medical degrees.' 
              : 'उच्च मांग वाली तकनीकी और चिकित्सा डिग्रियों के लिए हमारे 100% छात्रवृत्ति अभियान में शामिल हों।'}
          </p>
          <div className="flex items-center gap-2 bg-white/20 p-2 rounded-xl text-[10px] font-black uppercase tracking-widest inline-flex border border-white/10 backdrop-blur-sm">
            <Award size={14} className="text-orange-400" />
            {lang === 'en' ? '12,786 Seats Open' : '12,786 सीटें खुली हैं'}
          </div>
        </div>
      </div>

      {/* Level Selector */}
      <div className="flex p-1.5 bg-slate-200/50 rounded-2xl mb-6">
        {(['10th', '12th', 'grad'] as CourseLevel[]).map((lvl) => (
          <button
            key={lvl}
            onClick={() => { setLevel(lvl); setActiveTab('all'); }}
            className={`flex-1 py-3 text-xs font-black rounded-xl transition-all ${
              level === lvl 
                ? 'bg-white text-blue-700 shadow-sm scale-100' 
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            {levelLabels[lvl]}
          </button>
        ))}
      </div>

      {/* Search Bar */}
      <div className="relative mb-6">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
        <input 
          type="text" 
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={lang === 'en' ? "Search for courses..." : "कोर्स खोजें..."}
          className="w-full bg-white border border-slate-100 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-4 focus:ring-blue-500/10 shadow-sm transition-all"
        />
      </div>

      {/* Category Sub-Filters */}
      <div className="flex gap-2 mb-8 overflow-x-auto pb-2 no-scrollbar">
        {categories.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-2.5 rounded-full text-[10px] font-black uppercase tracking-wider whitespace-nowrap transition-all border ${
              activeTab === tab 
                ? 'bg-blue-600 text-white border-blue-600 shadow-md scale-105' 
                : 'bg-white text-slate-500 border-slate-100 shadow-sm hover:border-slate-200'
            }`}
          >
            {getCategoryLabel(tab)}
          </button>
        ))}
      </div>

      {/* Course List */}
      <div className="space-y-6">
        {filtered.map(course => {
          const courseImage = course.image || CATEGORY_PLACEHOLDERS[course.category];
          
          return (
            <div 
              key={course.id} 
              onClick={() => navigate(`/courses/${course.id}`)}
              className="bg-white rounded-[2rem] overflow-hidden shadow-sm border border-slate-100 flex flex-col hover:shadow-lg transition-all active:scale-[0.98] cursor-pointer group relative"
            >
              {/* Scholarship Ribbon Overlay */}
              {course.isScholarship && (
                <div className="absolute top-4 right-4 z-10 bg-orange-500 text-white text-[9px] font-black uppercase px-3 py-1.5 rounded-full flex items-center gap-1.5 shadow-lg shadow-orange-200 border border-orange-400">
                  <Sparkles size={10} />
                  {lang === 'en' ? 'Scholarship Available' : 'छात्रवृत्ति उपलब्ध'}
                </div>
              )}

              <div className="h-44 overflow-hidden relative">
                <img 
                  src={courseImage} 
                  alt={course.title[lang]} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = CATEGORY_PLACEHOLDERS.others;
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-4 left-4">
                   <span className="text-[9px] bg-white/20 backdrop-blur-md text-white font-black px-3 py-1 rounded-full uppercase border border-white/30 tracking-widest">
                    {course.category}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <div className="flex justify-between items-start gap-4 mb-2">
                  <h3 className="font-black text-lg text-slate-800 leading-tight tracking-tight flex-1">
                    {course.title[lang]}
                  </h3>
                  <div className="bg-blue-50 text-blue-600 p-2 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <ChevronRight size={20} />
                  </div>
                </div>
                
                <p className="text-sm text-slate-500 line-clamp-2 mb-4 font-medium leading-relaxed">
                  {course.shortDescription[lang]}
                </p>

                <div className="flex items-center gap-4 pt-4 border-t border-slate-50">
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 font-black uppercase tracking-widest">
                    <Clock size={14} className="text-blue-500" />
                    {course.duration}
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-400 font-black uppercase tracking-widest">
                    <GraduationCap size={14} className="text-emerald-500" />
                    {course.level === 'grad' ? (lang === 'en' ? 'Graduate' : 'स्नातक') : course.level}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {filtered.length === 0 && (
          <div className="text-center py-20 bg-white rounded-[3rem] border-2 border-dashed border-slate-100">
            <div className="bg-slate-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <GraduationCap size={40} className="text-slate-200" />
            </div>
            <p className="text-slate-400 font-black text-xs uppercase tracking-[0.2em]">
              {lang === 'en' ? 'No courses found' : 'कोई कोर्स नहीं मिला'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Courses;
