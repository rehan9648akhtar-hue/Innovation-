
import React from 'react';
import { Target, Eye, ShieldCheck, MapPin, Mail, Phone, MessageSquare } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface AboutProps {
  lang: Language;
}

const About: React.FC<AboutProps> = ({ lang }) => {
  return (
    <div className="pb-20 px-6 max-w-lg mx-auto pt-8">
      <h2 className="text-2xl font-bold text-slate-800 mb-6">
        {lang === 'en' ? 'Who We Are' : 'हम कौन हैं'}
      </h2>
      
      <div className="prose prose-slate prose-sm text-slate-600 mb-8">
        <p className="leading-relaxed">
          {lang === 'en' 
            ? 'Innovation Educational and Charitable Trust is a non-profit organization dedicated to bridging the educational gap for children. Through our "PRAGATI INDIA" mission, we ensure every student has the right to quality higher education regardless of their financial background.' 
            : 'इनोवेशन एजुकेशनल एंड चैरिटेबल ट्रस्ट एक गैर-लाभकारी संगठन है जो बच्चों के लिए शैक्षिक अंतर को पाटने के लिए समर्पित है। हमारे "प्रगति इण्डिया" मिशन के माध्यम से, हम यह सुनिश्चित करते हैं कि हर छात्र को उनकी वित्तीय पृष्ठभूमि की परवाह किए बिना गुणवत्तापूर्ण उच्च शिक्षा का अधिकार मिले।'}
        </p>
      </div>

      <div className="space-y-6">
        <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100">
          <div className="flex items-center gap-3 mb-3 text-blue-700 font-bold">
            <Target size={20} />
            {TRANSLATIONS.mission[lang]}
          </div>
          <p className="text-sm text-blue-800 opacity-90">
            {lang === 'en' 
              ? 'To provide 100% scholarship and support for technical and professional higher education to underprivileged students.' 
              : 'वंचित छात्रों को तकनीकी और व्यावसायिक उच्च शिक्षा के लिए 100% छात्रवृत्ति और सहायता प्रदान करना।'}
          </p>
        </div>

        <div className="bg-emerald-50 p-6 rounded-2xl border border-emerald-100">
          <div className="flex items-center gap-3 mb-3 text-emerald-700 font-bold">
            <Eye size={20} />
            {TRANSLATIONS.vision[lang]}
          </div>
          <p className="text-sm text-emerald-800 opacity-90">
            {lang === 'en'
              ? 'A future where no student is forced to leave studies due to a lack of money, and everyone gets admission in Government/State Universities.'
              : 'एक ऐसा भविष्य जहां किसी भी छात्र को पैसे की कमी के कारण पढ़ाई छोड़ने के लिए मजबूर न होना पड़े, और सभी को सरकारी/राज्य विश्वविद्यालयों में प्रवेश मिले।'}
          </p>
        </div>
      </div>

      <div className="mt-10 pt-10 border-t border-slate-100">
        <h3 className="font-bold text-lg text-slate-800 mb-6">{lang === 'en' ? 'Contact Details' : 'संपर्क विवरण'}</h3>
        <div className="space-y-4">
          <div className="flex items-start gap-4">
            <div className="bg-slate-100 p-2 rounded-lg text-slate-600">
              <MapPin size={20} />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-700">{lang === 'en' ? 'Registered Office' : 'पंजीकृत कार्यालय'}</div>
              <div className="text-xs text-slate-500">Near Veena Hospital, Gopalgarh, NH-28, Kasia, Kushinagar-274402 (U.P.)</div>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="bg-slate-100 p-2 rounded-lg text-slate-600">
              <Phone size={20} />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-700">{lang === 'en' ? 'Educational Helpline' : 'शैक्षिक हेल्पलाइन'}</div>
              <div className="text-xs text-slate-500 font-bold text-blue-600">9161-04-2518</div>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="bg-slate-100 p-2 rounded-lg text-slate-600">
              <MessageSquare size={20} />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-700">{lang === 'en' ? 'WhatsApp Support' : 'व्हाट्सएप सपोर्ट'}</div>
              <div className="text-xs text-slate-500 font-bold text-emerald-600">9161-04-2518</div>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="bg-slate-100 p-2 rounded-lg text-slate-600">
              <Mail size={20} />
            </div>
            <div>
              <div className="text-sm font-bold text-slate-700">{lang === 'en' ? 'Email' : 'ईमेल'}</div>
              <div className="text-xs text-slate-500">info@innovationtrust.org</div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-10 bg-slate-900 text-white p-8 rounded-3xl text-center">
        <h3 className="font-bold mb-2">{lang === 'en' ? 'Trust Registration' : 'ट्रस्ट पंजीकरण'}</h3>
        <p className="text-xs text-slate-400 mb-4 tracking-wider uppercase font-mono">REGD BY: INDIAN TRUST ACT 1882 (GOVT OF INDIA)</p>
        <div className="flex justify-center gap-2">
          <ShieldCheck className="text-emerald-400" size={16} />
          <span className="text-[10px] uppercase font-bold">{lang === 'en' ? 'Verified NGO' : 'सत्यापित एनजीओ'}</span>
        </div>
      </div>
    </div>
  );
};

export default About;
