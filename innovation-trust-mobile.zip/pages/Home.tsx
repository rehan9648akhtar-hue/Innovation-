
import React from 'react';
import { ArrowRight, Star, Users, GraduationCap, Heart, CheckCircle, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Language } from '../types';
import { TRANSLATIONS, EVENTS } from '../constants';
import Logo from '../components/Logo';

interface HomeProps {
  lang: Language;
}

const Home: React.FC<HomeProps> = ({ lang }) => {
  return (
    <div className="pb-20">
      {/* Hero Section */}
      <section className="relative h-96 bg-blue-700 flex items-center overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <img 
            src="https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=1000" 
            className="w-full h-full object-cover"
            alt="Education Hero"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-blue-950 via-blue-900/60 to-blue-800/20" />
        
        <div className="relative z-10 px-6 text-white max-w-lg mx-auto w-full text-center">
          <div className="w-24 h-24 bg-white rounded-3xl p-3 mx-auto mb-6 shadow-2xl flex items-center justify-center border-4 border-white/20">
            <Logo className="w-full h-full" />
          </div>
          <h2 className="text-3xl font-black leading-none mb-3 tracking-tighter">
            {TRANSLATIONS.welcome[lang]}
          </h2>
          <p className="text-blue-100 text-sm mb-10 max-w-[90%] mx-auto font-medium opacity-90 leading-relaxed">
            {TRANSLATIONS.tagline[lang]}
          </p>
          <div className="flex gap-4 justify-center">
            <Link to="/enroll" className="bg-white text-blue-900 px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl active:scale-95 transition-all">
              {TRANSLATIONS.enrollNow[lang]}
            </Link>
            <Link to="/donate" className="bg-orange-500 text-white px-8 py-3.5 rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl active:scale-95 transition-all">
              {TRANSLATIONS.navDonate[lang]}
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Quick View */}
      <div className="max-w-lg mx-auto px-4 -mt-10 relative z-20">
        <div className="bg-white rounded-[2rem] shadow-2xl p-6 grid grid-cols-3 divide-x divide-slate-50 border border-slate-50">
          <div className="text-center px-1">
            <div className="text-blue-600 font-black text-2xl tracking-tighter">12k+</div>
            <div className="text-[9px] text-slate-400 uppercase font-black tracking-widest mt-1">Scholarships</div>
          </div>
          <div className="text-center px-1">
            <div className="text-orange-600 font-black text-2xl tracking-tighter">50+</div>
            <div className="text-[9px] text-slate-400 uppercase font-black tracking-widest mt-1">Programs</div>
          </div>
          <div className="text-center px-1">
            <div className="text-emerald-600 font-black text-2xl tracking-tighter">10y+</div>
            <div className="text-[9px] text-slate-400 uppercase font-black tracking-widest mt-1">Legacy</div>
          </div>
        </div>
      </div>

      {/* Main Features */}
      <section className="mt-12 px-6 max-w-lg mx-auto">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-6 rounded-3xl border border-slate-50 shadow-sm flex flex-col items-center text-center transition-all hover:shadow-md">
            <div className="bg-blue-50 p-4 rounded-2xl mb-4 text-blue-600">
              <GraduationCap size={28} />
            </div>
            <h3 className="font-black text-xs mb-1 text-slate-800 uppercase tracking-wider">{lang === 'en' ? 'Free Education' : 'मुफ्त शिक्षा'}</h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">{lang === 'en' ? 'Quality & Inclusive' : 'गुणवत्ता और समावेशी'}</p>
          </div>
          <div className="bg-white p-6 rounded-3xl border border-slate-50 shadow-sm flex flex-col items-center text-center transition-all hover:shadow-md">
            <div className="bg-emerald-50 p-4 rounded-2xl mb-4 text-emerald-600">
              <CheckCircle size={28} />
            </div>
            <h3 className="font-black text-xs mb-1 text-slate-800 uppercase tracking-wider">{lang === 'en' ? 'Skill Dev' : 'कौशल विकास'}</h3>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">{lang === 'en' ? 'Placement Ready' : 'प्लेसमेंट तैयार'}</p>
          </div>
        </div>
      </section>

      {/* Latest Events / Our Impact */}
      <section className="mt-12 px-6 max-w-lg mx-auto mb-10">
        <div className="flex justify-between items-center mb-6">
          <div className="flex flex-col">
            <h3 className="font-black text-xl text-slate-900 tracking-tight">{TRANSLATIONS.latestEvents[lang]}</h3>
            <div className="w-12 h-1 bg-blue-600 rounded-full mt-1"></div>
          </div>
          <Link to="/gallery" className="text-blue-600 text-[10px] font-black uppercase tracking-widest flex items-center bg-blue-50 px-4 py-2 rounded-xl">
            {lang === 'en' ? 'View Gallery' : 'गैलरी देखें'} <ArrowRight size={14} className="ml-2" />
          </Link>
        </div>
        <div className="space-y-4">
          {EVENTS.map(event => (
            <div key={event.id} className="bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-50 flex h-32 group transition-all hover:shadow-md active:scale-[0.98]">
              <div className="w-32 h-full overflow-hidden shrink-0">
                <img src={event.image} alt={event.title[lang]} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
              </div>
              <div className="p-5 flex flex-col justify-center flex-1">
                <div className="text-[9px] text-blue-600 font-black uppercase tracking-[0.2em] mb-2">{event.date}</div>
                <h4 className="font-black text-sm text-slate-800 line-clamp-2 leading-tight mb-2 tracking-tight">{event.title[lang]}</h4>
                <div className="flex items-center gap-2 text-[9px] text-slate-400 font-bold uppercase tracking-widest">
                  <MapPin size={12} className="text-blue-400 shrink-0" />
                  <span className="truncate">{event.location}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
