
import React from 'react';
import { Users, Image as ImageIcon, Calendar, FileText, Settings, Shield, HelpCircle, LogOut } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Language } from '../types';
import Logo from '../components/Logo';

interface MoreProps {
  lang: Language;
}

const More: React.FC<MoreProps> = ({ lang }) => {
  const menuGroups = [
    {
      title: lang === 'en' ? 'Community' : 'समुदाय',
      items: [
        { icon: Users, label: lang === 'en' ? 'Volunteer with Us' : 'हमारे साथ स्वयंसेवा करें', path: '/volunteer' },
        { icon: Calendar, label: lang === 'en' ? 'Events & Camps' : 'कार्यक्रम और शिविर', path: '/events' },
        { icon: ImageIcon, label: lang === 'en' ? 'Photo Gallery' : 'फोटो गैलरी', path: '/gallery' },
      ]
    },
    {
      title: lang === 'en' ? 'Policies & Support' : 'नीतियां और समर्थन',
      items: [
        { icon: Shield, label: lang === 'en' ? 'Privacy Policy' : 'गोपनीयता नीति', path: '/privacy' },
        { icon: FileText, label: lang === 'en' ? 'Terms of Use' : 'उपयोग की शर्तें', path: '/terms' },
        { icon: HelpCircle, label: lang === 'en' ? 'FAQs' : 'अक्सर पूछे जाने वाले प्रश्न', path: '/faq' },
      ]
    }
  ];

  return (
    <div className="pb-24 px-6 max-w-lg mx-auto pt-8">
      <div className="flex items-center gap-5 mb-10 bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
        <div className="w-16 h-16 rounded-2xl bg-blue-50 p-2 flex items-center justify-center border border-blue-100 shadow-inner overflow-hidden">
          <Logo className="w-full h-full" />
        </div>
        <div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tighter">Innovation Trust</h2>
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em]">{lang === 'en' ? 'One Step Towards Sustainability' : 'स्थिरता की ओर एक कदम'}</p>
          <div className="mt-2 inline-flex items-center bg-slate-100 text-[9px] text-slate-400 font-mono px-2 py-0.5 rounded-full uppercase tracking-widest">V 1.2.0</div>
        </div>
      </div>

      <div className="space-y-10">
        {menuGroups.map((group, idx) => (
          <div key={idx} className="space-y-4">
            <h3 className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em] pl-2">
              {group.title}
            </h3>
            <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
              {group.items.map((item, i) => (
                <Link
                  key={i}
                  to={item.path}
                  className={`flex items-center gap-4 p-5 hover:bg-slate-50 transition-all group ${
                    i !== group.items.length - 1 ? 'border-b border-slate-50' : ''
                  }`}
                >
                  <div className="p-2 rounded-xl bg-slate-50 text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-600 transition-all">
                    <item.icon size={20} />
                  </div>
                  <span className="text-sm font-bold text-slate-700 flex-1 group-hover:text-slate-900 transition-colors">{item.label}</span>
                  <div className="text-slate-200 group-hover:text-slate-400 transition-all transform group-hover:translate-x-1">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 5l7 7-7 7"/></svg>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </div>

      <button className="w-full mt-12 flex items-center justify-center gap-3 text-slate-300 font-black text-[10px] uppercase tracking-[0.25em] hover:text-red-500 transition-colors py-5 rounded-3xl hover:bg-red-50 border border-transparent hover:border-red-100">
        <LogOut size={16} />
        {lang === 'en' ? 'Exit Application' : 'एप्लिकेशन से बाहर निकलें'}
      </button>
    </div>
  );
};

export default More;
