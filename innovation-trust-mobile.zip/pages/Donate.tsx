
import React, { useState } from 'react';
import { Heart, ShieldCheck, Award, Utensils, BookOpen, Check, Share2, X, Facebook, Twitter, MessageCircle } from 'lucide-react';
import { Language } from '../types';

interface DonateProps {
  lang: Language;
}

const Donate: React.FC<DonateProps> = ({ lang }) => {
  const [selectedAmount, setSelectedAmount] = useState<number | string>('');
  const [customActive, setCustomActive] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  const tiers = [
    {
      amount: 500,
      icon: BookOpen,
      color: 'blue',
      title: { en: 'Education Kit', hi: 'शिक्षा किट' },
      impact: { 
        en: 'Provides stationery and books for one child.', 
        hi: 'एक बच्चे के लिए स्टेशनरी और किताबें प्रदान करता है।' 
      }
    },
    {
      amount: 1500,
      icon: Award,
      color: 'emerald',
      title: { en: 'Skill Development', hi: 'कौशल विकास' },
      impact: { 
        en: 'Covers professional training fees for a vocational course.', 
        hi: 'एक व्यावसायिक पाठ्यक्रम के लिए पेशेवर प्रशिक्षण शुल्क कवर करता है।' 
      }
    },
    {
      amount: 3000,
      icon: Utensils,
      color: 'orange',
      title: { en: 'Monthly Support', hi: 'मासिक सहायता' },
      impact: { 
        en: 'Provides nutritional meals and healthcare for five students.', 
        hi: 'पांच छात्रों के लिए पौष्टिक भोजन और स्वास्थ्य सेवा प्रदान करता है।' 
      }
    }
  ];

  const handleTierClick = (amount: number) => {
    setSelectedAmount(amount);
    setCustomActive(false);
  };

  const handleCustomChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedAmount(e.target.value);
    setCustomActive(true);
  };

  const shareUrl = window.location.href;
  const shareText = lang === 'en' 
    ? "Help me support Innovation Trust in providing free education to children in India. Every contribution counts!" 
    : "भारत में बच्चों को मुफ्त शिक्षा प्रदान करने में इनोवेशन ट्रस्ट का समर्थन करने में मेरी सहायता करें। हर योगदान मायने रखता है!";

  const shareOptions = [
    {
      name: 'WhatsApp',
      icon: MessageCircle,
      color: 'bg-green-500',
      url: `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + " " + shareUrl)}`
    },
    {
      name: 'Facebook',
      icon: Facebook,
      color: 'bg-blue-700',
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`
    },
    {
      name: 'Twitter',
      icon: Twitter,
      color: 'bg-sky-500',
      url: `https://twitter.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`
    }
  ];

  return (
    <div className="pb-24 px-4 max-w-lg mx-auto pt-6">
      <div className="text-center mb-8">
        <div className="bg-red-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-red-500 shadow-sm">
          <Heart size={32} fill="currentColor" />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">
          {lang === 'en' ? 'Change a Life Today' : 'आज किसी का जीवन बदलें'}
        </h2>
        <p className="text-slate-500 text-sm">
          {lang === 'en' 
            ? 'Your contribution empowers underprivileged communities with education and support.' 
            : 'आपका योगदान वंचित समुदायों को शिक्षा और समर्थन के साथ सशक्त बनाता है।'}
        </p>
      </div>

      {/* Donation Tiers */}
      <div className="space-y-4 mb-8">
        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">
          {lang === 'en' ? 'Select an Impact' : 'एक प्रभाव चुनें'}
        </label>
        {tiers.map((tier) => {
          const Icon = tier.icon;
          const isSelected = selectedAmount === tier.amount && !customActive;
          
          return (
            <button
              key={tier.amount}
              onClick={() => handleTierClick(tier.amount)}
              className={`w-full bg-white p-4 rounded-2xl border-2 transition-all text-left flex items-start gap-4 relative group ${
                isSelected 
                  ? 'border-blue-600 ring-4 ring-blue-50 shadow-md' 
                  : 'border-slate-100 hover:border-slate-200'
              }`}
            >
              <div className={`p-3 rounded-xl transition-colors ${
                isSelected 
                  ? 'bg-blue-600 text-white' 
                  : `bg-${tier.color}-50 text-${tier.color}-600`
              }`}>
                <Icon size={24} />
              </div>
              <div className="flex-1 pr-6">
                <div className="flex items-center gap-2">
                  <span className="text-xl font-bold text-slate-800">₹{tier.amount}</span>
                  <span className="text-sm font-semibold text-slate-600 tracking-tight">• {tier.title[lang]}</span>
                </div>
                <div className="text-xs text-slate-500 mt-1 leading-relaxed font-medium">
                  {tier.impact[lang]}
                </div>
              </div>
              {isSelected && (
                <div className="absolute right-4 top-4 bg-blue-600 text-white rounded-full p-0.5">
                  <Check size={14} />
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Custom Amount */}
      <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-semibold text-sm">{lang === 'en' ? 'Custom Amount' : 'कस्टम राशि'}</h3>
          {customActive && <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-bold uppercase tracking-tighter">{lang === 'en' ? 'Manual Input' : 'मैनुअल इनपुट'}</span>}
        </div>
        <div className="relative mb-6">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-lg">₹</span>
          <input 
            type="number" 
            value={customActive ? selectedAmount : ''}
            onChange={handleCustomChange}
            onFocus={() => setCustomActive(true)}
            placeholder={!customActive ? (lang === 'en' ? "Enter custom amount" : "राशि दर्ज करें") : ""}
            className={`w-full bg-slate-50 border-2 rounded-xl py-4 pl-10 pr-4 text-xl font-bold focus:ring-0 outline-none transition-all ${
              customActive ? 'border-blue-600 bg-white shadow-inner' : 'border-transparent'
            }`}
          />
        </div>
        <button 
          className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl shadow-lg hover:bg-blue-700 active:scale-[0.98] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:grayscale disabled:cursor-not-allowed"
          disabled={!selectedAmount || Number(selectedAmount) <= 0}
        >
          <Heart size={18} fill="currentColor" />
          {lang === 'en' ? `Donate ₹${selectedAmount || '0'}` : `₹${selectedAmount || '0'} दान करें`}
        </button>
      </div>

      {/* Share Button */}
      <button 
        onClick={() => setIsShareModalOpen(true)}
        className="w-full mb-8 flex items-center justify-center gap-2 py-3 border-2 border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50 transition-colors text-sm"
      >
        <Share2 size={18} />
        {lang === 'en' ? 'Share this Donation Page' : 'इस दान पृष्ठ को साझा करें'}
      </button>

      {/* Trust Badges */}
      <div className="flex items-center justify-center gap-6 text-slate-400 opacity-80 pt-4">
        <div className="flex flex-col items-center gap-1">
          <ShieldCheck size={20} className="text-emerald-500" />
          <span className="text-[10px] uppercase font-bold tracking-widest">{lang === 'en' ? 'Secure' : 'सुरक्षित'}</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <ShieldCheck size={20} className="text-emerald-500" />
          <span className="text-[10px] uppercase font-bold tracking-widest">{lang === 'en' ? 'Tax Free' : 'टैक्स फ्री'}</span>
        </div>
        <div className="flex flex-col items-center gap-1">
          <ShieldCheck size={20} className="text-emerald-500" />
          <span className="text-[10px] uppercase font-bold tracking-widest">80G Reg</span>
        </div>
      </div>
      
      <p className="text-center text-[10px] text-slate-400 mt-8 px-8 leading-normal">
        {lang === 'en' 
          ? 'All donations are used exclusively for educational and charitable activities as per the Innovation Trust mandates.' 
          : 'सभी दान विशेष रूप से इनोवेशन ट्रस्ट के जनादेश के अनुसार शैक्षिक और धर्मार्थ गतिविधियों के लिए उपयोग किए जाते हैं।'}
      </p>

      {/* Share Modal */}
      {isShareModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-sm transition-opacity">
          <div className="w-full max-w-sm bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden animate-in slide-in-from-bottom-5 duration-300">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-slate-800">
                  {lang === 'en' ? 'Spread the Word' : 'प्रचार करें'}
                </h3>
                <button 
                  onClick={() => setIsShareModalOpen(false)}
                  className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400"
                >
                  <X size={24} />
                </button>
              </div>
              
              <p className="text-sm text-slate-500 mb-8 leading-relaxed">
                {lang === 'en' 
                  ? 'Encourage your friends and family to join our mission of empowering children through education.' 
                  : 'अपने दोस्तों और परिवार को शिक्षा के माध्यम से बच्चों को सशक्त बनाने के हमारे मिशन में शामिल होने के लिए प्रोत्साहित करें।'}
              </p>

              <div className="grid grid-cols-3 gap-4 mb-8">
                {shareOptions.map((option) => {
                  const Icon = option.icon;
                  return (
                    <a
                      key={option.name}
                      href={option.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex flex-col items-center gap-2 group"
                    >
                      <div className={`${option.color} text-white p-4 rounded-2xl shadow-lg group-hover:scale-110 transition-transform active:scale-95`}>
                        <Icon size={24} />
                      </div>
                      <span className="text-xs font-semibold text-slate-600">{option.name}</span>
                    </a>
                  );
                })}
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between gap-3">
                <span className="text-xs text-slate-400 truncate flex-1">{shareUrl}</span>
                <button 
                  onClick={() => {
                    navigator.clipboard.writeText(shareUrl);
                    alert(lang === 'en' ? 'Link copied!' : 'लिंक कॉपी हो गया!');
                  }}
                  className="text-blue-600 text-xs font-bold whitespace-nowrap px-3 py-1.5 bg-blue-50 rounded-lg"
                >
                  {lang === 'en' ? 'Copy Link' : 'लिंक कॉपी करें'}
                </button>
              </div>
            </div>
            <div className="bg-slate-50 p-4 text-center">
              <button 
                onClick={() => setIsShareModalOpen(false)}
                className="text-slate-500 text-sm font-semibold hover:text-slate-800"
              >
                {lang === 'en' ? 'Close' : 'बंद करें'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Donate;
