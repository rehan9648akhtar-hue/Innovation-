
import React, { useState } from 'react';
import { 
  User, 
  Phone, 
  GraduationCap, 
  MapPin, 
  CheckCircle2, 
  Calendar, 
  Hash, 
  Globe, 
  Briefcase, 
  IndianRupee, 
  Mail,
  ShieldCheck,
  ChevronRight,
  ChevronLeft,
  FileText
} from 'lucide-react';
import { Language } from '../types';
import { STATES_FOR_HIGHER_EDU, EDUCATIONAL_QUALIFICATIONS, COURSES } from '../constants';

interface EnrollProps {
  lang: Language;
}

const Enroll: React.FC<EnrollProps> = ({ lang }) => {
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    aadhaar: '',
    courseApplied: '',
    fullName: '',
    qualification: '',
    category: '',
    gender: 'M',
    dob: '',
    nationality: 'Indian',
    fatherName: '',
    motherName: '',
    parentOccupation: '',
    annualIncome: '',
    address: '',
    email: '',
    mobileSelf: '',
    mobileFather: '',
    mobileMother: '',
    localGuardian: '',
    preferredLocation: [] as string[],
    agreedToTerms: false
  });

  const nextStep = () => setStep(s => Math.min(s + 1, 4));
  const prevStep = () => setStep(s => Math.max(s - 1, 1));

  const handleLocationToggle = (loc: string) => {
    setFormData(prev => ({
      ...prev,
      preferredLocation: prev.preferredLocation.includes(loc)
        ? prev.preferredLocation.filter(l => l !== loc)
        : [...prev.preferredLocation, loc]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-6 text-center max-w-lg mx-auto animate-in fade-in duration-500">
        <div className="bg-emerald-100 text-emerald-600 p-8 rounded-full mb-6 shadow-xl shadow-emerald-100 animate-bounce">
          <CheckCircle2 size={64} />
        </div>
        <h2 className="text-2xl font-black text-slate-800 mb-4 tracking-tight">
          {lang === 'en' ? 'Registration Successful!' : 'पंजीकरण सफल!'}
        </h2>
        <p className="text-slate-500 mb-8 leading-relaxed font-medium">
          {lang === 'en' 
            ? 'Your membership application for "PRAGATI INDIA" has been received. Our team will verify your Aadhaar and certificates.' 
            : 'आपका "प्रगति इण्डिया" सदस्यता आवेदन प्राप्त हो गया है। हमारी टीम आपके आधार और प्रमाण पत्रों का सत्यापन करेगी।'}
        </p>
        <button 
          onClick={() => window.location.href = '#/courses'}
          className="bg-blue-600 text-white font-black px-10 py-4 rounded-2xl shadow-xl shadow-blue-100 active:scale-95 transition-all uppercase tracking-widest text-xs"
        >
          {lang === 'en' ? 'Explore More Courses' : 'अधिक कोर्स देखें'}
        </button>
      </div>
    );
  }

  return (
    <div className="pb-24 px-4 max-w-lg mx-auto pt-6">
      {/* Form Header */}
      <div className="bg-blue-600 rounded-3xl p-6 text-white mb-8 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-20">
          <FileText size={80} />
        </div>
        <div className="relative z-10">
          <h2 className="text-xl font-black mb-1 uppercase tracking-tight">
            {lang === 'en' ? 'Membership Form' : 'सदस्यता फॉर्म'}
          </h2>
          <p className="text-blue-100 text-[10px] font-bold uppercase tracking-widest opacity-80 mb-4">
            PRAGATI INDIA SCHOLARSHIP MISSION
          </p>
          
          {/* Progress Indicator */}
          <div className="flex items-center gap-2">
            {[1, 2, 3, 4].map((s) => (
              <div 
                key={s} 
                className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${
                  s <= step ? 'bg-white shadow-[0_0_10px_rgba(255,255,255,0.5)]' : 'bg-white/20'
                }`} 
              />
            ))}
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-[10px] font-black uppercase">Step {step} of 4</span>
            <span className="text-[10px] font-black uppercase text-orange-400">Innovation Trust</span>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        
        {/* STEP 1: Personal Identity */}
        {step === 1 && (
          <div className="space-y-5 animate-in slide-in-from-right-5">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">
              Personal Information
            </h3>
            
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Aadhaar Number</label>
              <div className="relative">
                <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input 
                  required
                  type="text" 
                  maxLength={12}
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold tracking-widest focus:ring-4 focus:ring-blue-500/10 outline-none" 
                  placeholder="1234 5678 9012"
                  value={formData.aadhaar}
                  onChange={(e) => setFormData({...formData, aadhaar: e.target.value})}
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Name (As per High School Certificate)</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input 
                  required
                  type="text" 
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none" 
                  placeholder="Full Name"
                  value={formData.fullName}
                  onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Date of Birth</label>
                <div className="relative">
                  <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                  <input 
                    required
                    type="date" 
                    className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none"
                    value={formData.dob}
                    onChange={(e) => setFormData({...formData, dob: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Gender</label>
                <select 
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 px-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none appearance-none"
                  value={formData.gender}
                  onChange={(e) => setFormData({...formData, gender: e.target.value})}
                >
                  <option value="M">Male / पुरुष</option>
                  <option value="F">Female / महिला</option>
                  <option value="T">Transgender</option>
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Nationality</label>
              <div className="relative">
                <Globe className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input 
                  type="text" 
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none"
                  value={formData.nationality}
                  onChange={(e) => setFormData({...formData, nationality: e.target.value})}
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Academic Choice */}
        {step === 2 && (
          <div className="space-y-5 animate-in slide-in-from-right-5">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">
              Academic Details
            </h3>

            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Course to be Applied</label>
              <div className="relative">
                <GraduationCap className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <select 
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none appearance-none"
                  value={formData.courseApplied}
                  onChange={(e) => setFormData({...formData, courseApplied: e.target.value})}
                >
                  <option value="">Select a Course</option>
                  {COURSES.map(c => <option key={c.id} value={c.title.en}>{c.title.en}</option>)}
                  <option value="Other">Other (Special Mention)</option>
                </select>
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Educational Qualification</label>
              <div className="grid grid-cols-2 gap-2">
                {EDUCATIONAL_QUALIFICATIONS.map((qual) => (
                  <button
                    key={qual}
                    type="button"
                    onClick={() => setFormData({...formData, qualification: qual})}
                    className={`p-3 text-[10px] font-black uppercase rounded-xl border transition-all ${
                      formData.qualification === qual 
                        ? 'bg-blue-600 text-white border-blue-600 shadow-md' 
                        : 'bg-white text-slate-500 border-slate-100 hover:border-slate-300'
                    }`}
                  >
                    {qual}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Category (SC/ST/OBC/GEN)</label>
              <input 
                type="text" 
                className="w-full bg-white border border-slate-200 rounded-2xl py-4 px-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none" 
                placeholder="Category"
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value})}
              />
            </div>
          </div>
        )}

        {/* STEP 3: Parents & Contact */}
        {step === 3 && (
          <div className="space-y-5 animate-in slide-in-from-right-5">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">
              Parents & Contact Details
            </h3>

            <div className="grid grid-cols-1 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Father's Name</label>
                <input 
                  type="text" 
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 px-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none" 
                  value={formData.fatherName}
                  onChange={(e) => setFormData({...formData, fatherName: e.target.value})}
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Mother's Name</label>
                <input 
                  type="text" 
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 px-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none" 
                  value={formData.motherName}
                  onChange={(e) => setFormData({...formData, motherName: e.target.value})}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Parent's Occupation</label>
                <div className="relative">
                  <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                  <input 
                    type="text" 
                    className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-10 pr-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none" 
                    value={formData.parentOccupation}
                    onChange={(e) => setFormData({...formData, parentOccupation: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Annual Income</label>
                <div className="relative">
                  <IndianRupee className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                  <input 
                    type="number" 
                    className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-10 pr-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none" 
                    value={formData.annualIncome}
                    onChange={(e) => setFormData({...formData, annualIncome: e.target.value})}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Full Address</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-4 text-slate-300" size={18} />
                <textarea 
                  rows={3}
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none resize-none" 
                  placeholder="Street, City, District, Pincode"
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Email ID</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input 
                  type="email" 
                  className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-sm font-bold focus:ring-4 focus:ring-blue-500/10 outline-none" 
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Contact Numbers</label>
              <div className="grid grid-cols-2 gap-4">
                <input type="tel" placeholder="Mobile (Self)" className="bg-white border border-slate-200 rounded-xl p-3 text-xs font-bold outline-none" value={formData.mobileSelf} onChange={(e) => setFormData({...formData, mobileSelf: e.target.value})} />
                <input type="tel" placeholder="Father's Mobile" className="bg-white border border-slate-200 rounded-xl p-3 text-xs font-bold outline-none" value={formData.mobileFather} onChange={(e) => setFormData({...formData, mobileFather: e.target.value})} />
                <input type="tel" placeholder="Mother's Mobile" className="bg-white border border-slate-200 rounded-xl p-3 text-xs font-bold outline-none" value={formData.mobileMother} onChange={(e) => setFormData({...formData, mobileMother: e.target.value})} />
                <input type="tel" placeholder="Local Guardian" className="bg-white border border-slate-200 rounded-xl p-3 text-xs font-bold outline-none" value={formData.localGuardian} onChange={(e) => setFormData({...formData, localGuardian: e.target.value})} />
              </div>
            </div>
          </div>
        )}

        {/* STEP 4: Preferences & T&C */}
        {step === 4 && (
          <div className="space-y-5 animate-in slide-in-from-right-5">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-2 px-1">
              Study Location & Confirmation
            </h3>

            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider pl-1">Choice of location for higher education</label>
              <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto p-1 no-scrollbar">
                {STATES_FOR_HIGHER_EDU.map((loc) => (
                  <button
                    key={loc}
                    type="button"
                    onClick={() => handleLocationToggle(loc)}
                    className={`flex items-center gap-2 p-3 text-[9px] font-black uppercase rounded-xl border transition-all ${
                      formData.preferredLocation.includes(loc) 
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-md' 
                        : 'bg-white text-slate-500 border-slate-100'
                    }`}
                  >
                    <CheckCircle2 size={12} className={formData.preferredLocation.includes(loc) ? 'opacity-100' : 'opacity-20'} />
                    {loc}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100">
              <div className="flex gap-4">
                <input 
                  type="checkbox" 
                  id="tc" 
                  className="mt-1 w-5 h-5 rounded-lg text-blue-600 border-slate-300 focus:ring-blue-500" 
                  checked={formData.agreedToTerms}
                  onChange={(e) => setFormData({...formData, agreedToTerms: e.target.checked})}
                />
                <label htmlFor="tc" className="text-[11px] text-slate-600 leading-relaxed font-medium">
                  I hereby declare that the information provided is true to the best of my knowledge. I have read and understood the terms and conditions of the <strong>Mission PRAGATI INDIA</strong> scholarship.
                </label>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 p-4 border border-blue-100 bg-blue-50 rounded-2xl text-blue-700">
              <ShieldCheck size={20} />
              <span className="text-[10px] font-black uppercase tracking-widest leading-none">Registered Govt. of India (Trust Act 1882)</span>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex gap-4 pt-6">
          {step > 1 && (
            <button 
              type="button"
              onClick={prevStep}
              className="flex-1 bg-white border border-slate-200 text-slate-500 font-black py-4 rounded-2xl flex items-center justify-center gap-2 active:scale-95 transition-all shadow-sm"
            >
              <ChevronLeft size={18} />
              {lang === 'en' ? 'Previous' : 'पीछे'}
            </button>
          )}
          
          {step < 4 ? (
            <button 
              type="button"
              onClick={nextStep}
              className="flex-[2] bg-blue-600 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-2 active:scale-95 transition-all shadow-xl shadow-blue-100"
            >
              {lang === 'en' ? 'Continue' : 'जारी रखें'}
              <ChevronRight size={18} />
            </button>
          ) : (
            <button 
              type="submit"
              disabled={!formData.agreedToTerms}
              className="flex-[2] bg-emerald-600 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-2 active:scale-95 transition-all shadow-xl shadow-emerald-100 disabled:opacity-50 disabled:grayscale"
            >
              {lang === 'en' ? 'Submit Application' : 'आवेदन जमा करें'}
              <CheckCircle2 size={18} />
            </button>
          )}
        </div>
      </form>

      {/* Helpline Footer */}
      <div className="mt-10 pt-8 border-t border-slate-100 text-center">
        <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em] mb-4">Helpline & Support</p>
        <div className="flex items-center justify-center gap-2 text-blue-600 font-black text-lg">
          <Phone size={20} />
          9161-04-2518
        </div>
        <p className="text-[9px] text-slate-400 mt-2 italic">
          {lang === 'en' ? '* Valid for students of India, Nepal, Bhutan & Bangladesh' : '* भारत, नेपाल, भूटान और बांग्लादेश के छात्रों के लिए मान्य'}
        </p>
      </div>
    </div>
  );
};

export default Enroll;
